package com.example.ble_esp32;

public class SwipeRezfreshLayout {
}
