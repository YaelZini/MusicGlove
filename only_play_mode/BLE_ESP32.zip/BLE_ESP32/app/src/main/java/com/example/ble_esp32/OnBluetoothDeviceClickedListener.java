package com.example.ble_esp32;

public interface OnBluetoothDeviceClickedListener {
    void onBluetoothDeviceClicked(String name, String address);
}
